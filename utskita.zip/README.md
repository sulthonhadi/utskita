# diWOCO

# TEMPLATE FRONT PAGE JANGAN DI EDIT !

## UPLOAD VIEW

### - DASHBOARD ADMIN : FOLDER VIEW/DASHBOARD ADMIN/UPLOAD DISINI

### - HALAMAN DEPAN : FOLDER VIEW/UPLOAD DISINI

## CONTROLLER

### 1 Mahasiswa boleh gabung controller, tapi jangan 1 controller di buat semua, ngerti ya, jangan goblok ya..
