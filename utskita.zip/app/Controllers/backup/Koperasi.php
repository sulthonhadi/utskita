<?php

namespace App\Controllers;

class Koperasi extends BaseController
{
    public function index()
    {
        return view('koperasi/koperasi');
    }
}
