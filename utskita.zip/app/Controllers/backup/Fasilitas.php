<?php

namespace App\Controllers;

class Fasilitas extends BaseController
{
    public function perpus()
    {
        return view('pages/Ajeng/perpus');
    }
}
