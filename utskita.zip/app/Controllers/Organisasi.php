<?php

namespace App\Controllers;

class Organisasi extends BaseController
{
    public function ukm()
    {
        return view('p_ukm/ukm_base');
    }
}
