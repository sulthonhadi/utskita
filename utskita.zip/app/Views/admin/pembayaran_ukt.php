<!DOCTYPE html>
<html>
  <head>
    <title>Pogram Studi</title>
  </head>
  <body>
    <style>
      th {
        background-color: green;
        color: #fff;
      }
      table {
        margin: auto;
        top: 500px;
      }
      .apaaja {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .buaya {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .kucing {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .bunga {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .buah {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .aku {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .kamu {
        background-color: grey;
        color: #fff;
        podding: 5px;
      }
      .kita {
        background-color: grey;
        color: #fff;
        podding: 5px;
      }
      .kucing {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .kucing {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .kucing {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .bunga {
        background-color: gray;
        color: #fff;
        podding: 5px;
      }
      .bunga {
        background-color: grey;
        color: #fff;
        podding: 5px;
      }
      .bunga {
        background-color: grey;
        color: #fff;
        podding: 5px;
      }
    </style>

    <table border="1" cellspacing="0">
      <tr>
        <th rowspan="2">PROGRAM STUDI</th>
        <th colspan="2">UKT</th>
        <th rowspan="2">UTS/UAS</th>
      </tr>
      <tr>
        <th>SPP/SEMESTER</th>
        <th>HEREGRISTASI</th>
      </tr>
      <tr>
        <td class="apaaja">Pendidikan Agama Islam</td>
        <td class="apaaja">2.200.000</td>
        <td class="apaaja">300.000</td>
        <td class="apaaja">200.000</td>
      </tr>
      <tr>
        <td class="buaya">Pendidikan Bahasa Arab</td>
        <td class="buaya">2.000.000</td>
        <td class="buaya">300.000</td>
        <td class="buaya">200.000</td>
      </tr>
      <tr>
        <td class="kucing">Pendidikan Matematika</td>
        <td class="kucing">1.800.000</td>
        <td class="kucing">300.000</td>
        <td class="kucing">200.000</td>
      </tr>
      <tr>
        <td class="bunga">Pendidikan Biologi</td>
        <td class="bunga">1.800.000</td>
        <td class="bunga">300.000</td>
        <td class="bunga">200.000</td>
      </tr>
      <tr>
        <td class="buah">Pendidikan Fisika</td>
        <td class="buah">1.600.000</td>
        <td class="buah">300.000</td>
        <td class="buah">200.000</td>
      </tr>
      <tr>
        <td class="aku">Pendidikan Bahasa Inggris</td>
        <td class="aku">1.800.000</td>
        <td class="aku">300.000</td>
        <td class="aku">200.000</td>
      </tr>
      <tr>
        <td class="kamu">Manajemen</td>
        <td class="kamu">2.200.000</td>
        <td class="kamu">300.000</td>
        <td class="kamu">200.000</td>
      </tr>
      <tr>
        <td class="kita">Ekonomi Syariah</td>
        <td class="kita">1.800.000</td>
        <td class="kita">300.000</td>
        <td class="kita">200.000</td>
      </tr>
      <tr>
        <td class="kucing">Sistem Informasi</td>
        <td class="kucing">1.800.000</td>
        <td class="kucing">300.000</td>
        <td class="kucing">200.000</td>
      </tr>
      <tr>
        <td class="kucing">Informatika</td>
        <td class="kucing">1.800.000</td>
        <td class="kucing">300.000</td>
        <td class="kucing">200.000</td>
      </tr>
      <tr>
        <td class="kucing">Teknologi Hasil pertanian</td>
        <td class="kucing">1.400.000</td>
        <td class="kucing">300.000</td>
        <td class="kucing">200.000</td>
      </tr>
      <tr>
        <td class="bunga">Rekayasa pertanian & biosistem</td>
        <td class="bunga">1.400.000</td>
        <td class="bunga">300.000</td>
        <td class="bunga">200.000</td>
      </tr>
      <tr>
        <td class="bunga">Agribisnis</td>
        <td class="bunga">1.600.000</td>
        <td class="bunga">300.000</td>
        <td class="bunga">200.000</td>
      </tr>
      <tr>
        <td class="bunga">Agroekoteknologi</td>
        <td class="bunga">1.600.000</td>
        <td class="bunga">300.000</td>
        <td class="bunga">200.000</td>
      </tr>
    </table>
  </body>
</html>
