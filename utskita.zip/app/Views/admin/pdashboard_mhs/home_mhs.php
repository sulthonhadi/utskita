<div class="info text-center">
    <h2>INFORMASI MAHASISWA</h2>
</div>
<table border="2" class="table table-bordered text-center shadow-lg ">
    <div class="row">
        <thead class="bg-success">
            <th></th>
            <th>KRS</th>
            <th>UTS</th>
            <th>UAS</th>
        </thead>
        <tbody>
            <tr>
                <td>Tanggal Mulai</td>
                <td>4 Februari 2023</td>
                <td>8 April 2023</td>
                <td>1 Juli 2023</td>
            </tr>
            <tr>
                <td>Tanggal Selesai</td>
                <td>28 Februari 2023</td>
                <td>13 April 2023</td>
                <td>6 Juli 2023</td>
            </tr>
        </tbody>
    </div>
</table>
<div class="informasi mt-5">
    <H2>PENGUMUMAN :</H2><br>
    <h5>
        <P>
            > Bagi Mahasiswa Baru, Pemilihan Matakuliah telah dilakukan oleh sistem namun tetap memiliki kewajiban untuk mencetak KRS tersebut rangkap 2 dengan kertas warna putih dan warna biru muda, lalu meminta tanda tangan ke dosen wali dan menyerahkan KRS tersebut ke staf akademik masing-masing fakultas.
        </P>
        <p>
            > Diberitahukan kepada mahasiswa Unwaha:
            Dalam melaksanakan KRS setelah memilih matakuliah yang diambil, harap mencetak rangkap dua di kertas warna putih dan warna biru muda. Setelah itu menghadap dosen wali untuk meminta persetujuan/tanda tangan.
            Setelah mendapatkan tanda tangan dosen wali harap segera menyerahkan ke staf akademik fakultas masing-masing untuk dilakukan validasi di SIA. KRS yang belum divalidasi pihak akademik dianggap belum melakukan KRS dan daftar hadir perkuliahan tidak akan muncul.
        </p>
    </h5>
</div>