<head>

</head>

<body>
    <h1 align='center'>Profil dan Judul Laporan Akhir Mahasiswa</h1>
    <h2 align='center'>Universitas KH.A Wahab Hasbullah Jombang</h2>
</body>
<div class='container'>
    <div class='col4'>
        <div class='image'>
            <img alt='evi' height='213' src='assets/img/evi.jpg' width='320'>
        </div>
        <div class='copy'>
            <h3 class="card-title text-center"> EVI LAILY ZAKIYATUL CHIKMAH </h3>
            <table class="table">
                <thead class="table-dark">
                    <th>
                        <h4> NIM : 1901011644 </h4>
                    </th>
                    <th>
                        <h4> Prodi : Pendidikan Agama Islam </h4>
                    </th>
            </table>
            <p>
                <li><a href="assets/file/evi.pdf?page=home">
                        Hubungan Antara Peran Orang Tua Dengan Prestasi Belajar Anak
                    </a></li>
                </a>
            </p>
        </div>
        <div class='clear'></div>
    </div>
    <div class='col4'>
        <div class='image'>
            <img alt='alfiatul' height='213' src='assets/img/alfiatul.jpg' width='320'>
        </div>
        <div class='copy'>
            <h3 class="card-title text-center"> ALFIATUL LATHIFAH </h3>
            <table class="table">
                <thead class="table-dark">
                    <th>
                        <h4> NIM : 1704120058 </h4>
                    </th>
                    <th>
                        <h4> Prodi : Pendidikan Matematika </h4>
                    </th>
            </table>
            <p>
                <li><a href="assets/file/alfiatul.pdf?page=home">
                        Pengembangan Soal Matematika Model Pisa Konten Space & Shape Untuk Menunjang Pemikiran Matematis Peserta Didik SMP/MTs
                    </a></li>
                </a>
            </p>
        </div>
        <div class='clear'></div>
    </div>
    <div class='col4'>
        <div class='image'>
            <img alt='maya' height='213' src='assets/img/maya.jpg' width='320'>
        </div>
        <div class='copy'>
            <h3 class="card-title text-center"> MAYA KHOLIDA </h3>
            <table class="table">
                <thead class="table-dark">
                    <th>
                        <h4> NIM : 1904120112 </h4>
                    </th>
                    <th>
                        <h4> Prodi : Pendidikan Matematika </h4>
                    </th>
            </table>
            <p>
                <li><a href="assets/file/kholida.pdf?page=home">
                        Pengembangan Game Edukasi Berorientasi Kemampuan Berfikir Kreatif Siswa Materi Limit Fungsi Aljabar Kelas XI SMA/MA
                    </a></li>
                </a>
            </p>
        </div>
        <div class='clear'></div>
    </div>
</div>