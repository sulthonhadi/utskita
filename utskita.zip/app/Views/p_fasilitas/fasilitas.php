<?php
echo $this->extend('template_by_nofal');
echo $this->section('content') ?>

<div class="container">

    <h3>fasilitas kampus</h3>
    <img class="w-100" src="<?= base_url() ?>assets/8-scaled.jpg" alt="8-scaled.jpg">
    <h4><br>fasilitas kampus</h4>
    <div class="newspapper">
        <h2>menyediakan banyak fasilitas unggulan yang mendukung pembelajaran mahasiswa dalam segi akademik maupun non-akademik. Fasilitas tersebut untuk menunjang mahasiswa dalam menciptakan karya selama masa studinya. Selain itu ada juga fasilitas umum lainnya seperti Klinik dan Klinik Fisioterapi yang ditujukan untuk Dosen, Mahasiswa dan Masyarakat umum. Guna untuk mendukung akses pelayanan kesehatan di dalam Kampus maupun di luar Kampus.</h2>
    </div>
    <div class="content">
        <img class="w-100" src="assets/Gedung-Baru-UNWAHA.jpg" alt="Gedung-Baru-UNWAHA.jpg">
        <h1>gedung baru</h1>
        <p>tempat Ruang Kelas mahasiswa yang dilengkapi dgn AC dan LCD Projector untuk menciptakan suasana belajar yang nyaman & bersih serta memudahkan Dosen dalam menyampaikan materi.</p>
    </div>
</div>
<div class=content1>
    <img class="w-100" src="assets/download.jpg" alt="download.jpg">
    <h1>lab komputer</h1>
    <p>Proses belajar mengajar materi komputer didukung dengan 2 (dua) Lab Komputer yang masing-masing terdiri dari 40 unit komputer berbasis multimedia dengan teknologi core 2 duo dan didukung dengan layanan internet broadband up to 80 Mbps fiber optic backbone.</p>
</div>
</div>
<div class=content2>
    <img class="w-100" src="assets/download (1).jpg " alt="download (1).jpg">
    <h1>lab bahasa</h1>
    <p>Ruang Kelas yang dilengkapi dgn AC,Tv lcd, LCD Projector untuk menciptakan suasana belajar yang nyaman & bersih serta memudahkan Dosen dalam menyampaikan materi.</p>
</div>
<div class=content3>
    <img class="w-100" src="assets/download (2).jpg" alt="download (2).jpg">
    <h1>alat bantu pembelajaran</h1>
    <p>Alat-alat bantu belajar seperti multimedia LCD Projector,tv lcd dan Seperangkat Komputer disetiap kelas sangat menentukan besarnya daya serap dr setiap Mata Kuliah yg disampaikan oleh Dosen shg memudahkan mhswa untuk memahami setiap Mata Kuliah yang diajarkan.</p>
</div>
</div>
</div>
<?php echo $this->endSection() ?>