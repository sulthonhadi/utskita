<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <style>
/* body{
    background-image: url(./gambar4.jpg);
    background-size: cover;
    background-attachment:fixed;
  background-position: center;
  background-repeat: no-repeat;
    
   
} */
.navbar {
  overflow: hidden;
  background-color:#191970 ;
  
  top: 0;
  width: 100%;
}
.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 7px 10px;
  text-decoration: none;
  font-size: 17px;
  
}
.navbar a:hover {
  background: #ddd;
  color: black;
}


</style>
</head>

<body>
     
<nav class="navbar navbar-expand-sm shadow">
        <div class="container-fluid">
            <a class="nav-link text-white" href="index.php">Beasiswa</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

</body>
</html>