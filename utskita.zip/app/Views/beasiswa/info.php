<?php
include("nav.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<style>
.card{
  width: auto;
  margin: auto;
}
</style>
<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
            <div class="card-body">
                <div class="card mt-5" style="width: 23rem;">
                        <img src="./gambar1.jpg" class="card-img-top" alt="...">
                            <!-- <p class="card-text">informasi</p> -->
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card-body">
                <div class="card mt-5" style="width: 23rem;">
                        <img src="./gambar2.jpg" class="card-img-top" alt="...">
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card-body">
                <div class="card mt-5" style="width: 23rem;">
                        <img src="./gambar3.jpg" class="card-img-top" alt="...">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>